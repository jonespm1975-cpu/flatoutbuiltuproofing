# Terms of Use — DRAFT FOR REVIEW

**Status:** Template only; complete and review before launch. Operator: [legal name/business name], [address], [contact email]. Effective date: [date].

## 1. About the service
Flat Out Built-Up Roofing provides independent educational material about roofing skills and safety. It is not a substitute for competent practical training, site-specific risk assessments, professional advice, manufacturer instructions or official assessment. We are not endorsed by CITB or CSCS unless a formal endorsement is obtained and accurately described.

## 2. Accounts and acceptable use
If accounts are introduced, users must provide accurate details, keep credentials secure and not misuse the service, upload unlawful material, interfere with security or copy content in breach of rights. Add a real account deletion/contact process before enabling accounts.

## 3. Educational and safety disclaimer
Content is general learning information. Roofing and hot works carry serious risks. Users must follow current law, HSE guidance, site procedures, competent supervision and the relevant manufacturer's current instructions. Do not undertake work beyond your competence. Nothing here removes statutory rights or responsibility for any liability that cannot lawfully be excluded.

## 4. Paid digital courses
Course name, features, access period, price (including applicable taxes), technical requirements and any limitations must be shown clearly before purchase. Proposed introductory course price: £19.99, subject to final configuration. Do not advertise features that are not available.

## 5. Orders, cancellation and digital content
Before checkout, provide the required pre-contract information, total price, payment details, delivery/access timing, complaint contact and cancellation information. For immediate digital content, do not start supply in a way intended to remove a cancellation right unless the required express prior consent and acknowledgement are collected and confirmed as required by law. Explain statutory rights and the process for cancellation/refund. This clause must be tailored to the actual checkout flow and reviewed by a UK consumer-law adviser.

## 6. Payments, refunds and taxes
Payments are processed by [payment provider]. Explain when an order is accepted, how receipts are issued, how refunds are requested and how payment disputes are handled. Do not describe funds as held in-app; payout and settlement are controlled by the provider and its terms. Obtain tax/accounting advice appropriate to the business.

## 7. Intellectual property
Identify the owner/licensor of the logo, videos, course text and other content. Users receive a limited personal, non-transferable licence to access purchased material, subject to the purchase terms. Do not include third-party content without permission.

## 8. Advertising and sponsorship
Clearly identify paid promotions, affiliate links and sponsored educational content. Sponsorship does not guarantee product suitability or replace manufacturer advice. Disclose material connections clearly and prominently.

## 9. Availability and changes
Explain planned maintenance, support arrangements, course updates and what happens if a paid course is discontinued. Do not promise uninterrupted access unless it can be delivered.

## 10. Complaints and disputes
Contact [support email/address]. Specify the applicable governing law and jurisdiction only after confirming the business location and customer audience. Nothing in these terms limits mandatory consumer rights.

## 11. Contact
[Legal business name, postal address and contact email].