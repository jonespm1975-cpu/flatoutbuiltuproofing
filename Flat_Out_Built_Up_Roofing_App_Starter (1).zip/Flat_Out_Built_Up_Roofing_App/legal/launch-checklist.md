# UK Launch Checklist — Flat Out Built-Up Roofing

This is a practical checklist, not a certification of legal compliance.

## Business and customer information
- [ ] Confirm legal operator name, business type, service address and customer support/privacy email.
- [ ] Confirm business/tax/VAT position with a qualified accountant or HMRC guidance.
- [ ] Publish reviewed Terms, Privacy Notice, course purchase/refund information and cookie/ad notice.
- [ ] Complete UK GDPR data mapping, lawful-basis assessment, retention schedule, processor agreements and data-subject request process.
- [ ] Assess whether an ICO data protection fee is payable and complete any required registration.
- [ ] Implement consent for non-essential cookies/advertising where required and test reject/withdraw options.
- [ ] Review accessibility and make important safety information readable on mobile.

## Payments and access control
- [ ] Open and verify a payment-provider account; configure business and payout details directly with provider.
- [ ] Keep secret keys only in server environment variables/secrets storage; never in browser code or public GitHub.
- [ ] Use HTTPS, verify webhook signatures, handle duplicate webhook events idempotently, and grant course access only after verified payment.
- [ ] Implement secure owner login, MFA if available, role-based access, rate limiting and audit logs.
- [ ] Build database-backed order, refund, fees and payout reporting; reconcile with provider records.
- [ ] Test successful, failed, abandoned, duplicate, refunded and disputed payments in test mode before live mode.
- [ ] Document support, incident response, backups and restore procedures.

## Course content and advertising
- [ ] Review all roofing guidance against current HSE material, relevant standards and manufacturer instructions.
- [ ] Avoid implying CITB/CSCS endorsement or official certification without authorisation.
- [ ] Ensure practice questions are original and do not reproduce protected question banks.
- [ ] Clearly label sponsored content, ads and affiliate relationships; check ad network eligibility and policies.
- [ ] Avoid claims of guaranteed outcomes, qualifications or earnings.

## Mobile distribution
- [ ] Test the PWA on current iOS Safari and Android Chrome, including home-screen installation and offline behaviour.
- [ ] Test keyboard navigation, contrast, text resizing, broken links and mobile performance.
- [ ] If publishing in app stores, review current Apple/Google digital-content billing and developer requirements before choosing the payment flow.
- [ ] Decide whether a native app is worth the additional development and store-review process.

## Final go/no-go
- [ ] Legal/consumer review completed.
- [ ] Security and payment tests passed.
- [ ] Privacy and cookie consent tested.
- [ ] Support contact and refund process operational.
- [ ] Owner dashboard is server-authenticated; no live secrets or personal data in public repository.
- [ ] Do not launch paid checkout until all required boxes above are complete.