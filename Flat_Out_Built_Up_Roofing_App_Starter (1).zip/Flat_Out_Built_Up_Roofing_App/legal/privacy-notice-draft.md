# Privacy Notice — DRAFT FOR REVIEW

**Status:** Draft template only. Complete every bracketed item and obtain suitable UK data-protection review before publication.

**Who we are.** Flat Out Built-Up Roofing is operated by [legal name / business name], of [business address]. Contact: [privacy email]. We are the data controller for personal data described in this notice, where applicable.

**Information we may process.** Depending on the features actually launched, this may include account/contact details, course enrolments and progress, order and refund records, support messages, device/log/security information, and cookie or analytics data where enabled. Do not collect information that is not needed.

**Purposes and lawful bases.** We may process data to provide purchased courses and accounts (contract), meet accounting or other legal duties (legal obligation), secure and maintain the service (legitimate interests where balanced against your rights), and send optional marketing only where a valid lawful basis and required consent exist. Identify the specific basis for each activity before launch.

**Payments.** Payments should be handled by the named payment service provider [provider and privacy link]. We should not store full payment-card details. The provider may process data under its own privacy terms.

**Cookies and analytics.** List all essential, analytics, advertising and third-party cookies/SDKs actually used. Obtain consent before setting non-essential cookies or similar technologies where required. Provide a working preference/withdrawal mechanism.

**Sharing and transfers.** List hosting, payment, email, analytics, advertising and support processors; explain their purposes and any international transfers and safeguards. Do not publish this notice until the actual vendors are known.

**Retention.** Set a documented retention schedule for account data, learning progress, support records, transaction/tax records, security logs and marketing preferences. Delete or anonymise data when no longer needed, subject to legal retention duties.

**Your rights.** Depending on the circumstances, you may have rights to access, rectify, erase, restrict, object, portability and withdraw consent. Contact [privacy email]. You may complain to the UK Information Commissioner's Office (ICO): https://ico.org.uk/.

**Children.** State the intended audience and age policy. Add suitable safeguards if children may use the service.

**Security and incidents.** Describe actual access controls, encryption, backups, breach response and how to contact us. Do not claim safeguards that are not implemented.

**Changes.** Publish an effective date and explain how material changes will be communicated.

**Effective date:** [date].