# Course Purchase and Refund Information — DRAFT

Course: Three-Layer Torch-On Roofing: Foundations (working title)
Proposed price: £19.99 one-off, including applicable taxes if required. Confirm the final tax treatment before launch.

Before payment, clearly display the course contents, delivery format, access period, system requirements, total price, provider identity/contact details, and support/refund route.

For digital content supplied immediately, design checkout to collect any legally required express request for immediate supply and acknowledgement about the effect on cancellation rights. Use a clear unchecked box and store the timestamp/version of the wording and order record where advised. Do not assume a blanket “no refunds” rule overrides statutory rights.

Publish a practical contact route for access problems, duplicate payments, mistaken purchases and refund requests. Explain the process and expected response time. Follow consumer law and payment-provider requirements. Have a UK consumer-law adviser review the exact checkout wording and process before live payments.