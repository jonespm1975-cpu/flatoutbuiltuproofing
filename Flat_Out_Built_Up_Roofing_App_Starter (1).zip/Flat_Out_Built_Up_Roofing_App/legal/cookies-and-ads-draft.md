# Cookie, Analytics and Advertising Notice — DRAFT

Do not publish until the website/app's actual cookies, SDKs and third parties have been inventoried.

- Explain strictly necessary storage and why it is used.
- List each analytics, advertising, embedded media and attribution tool, the data collected, purpose, provider, duration and any international transfer.
- Obtain prior consent for non-essential cookies or similar technologies where required; do not load ad/analytics tags before consent where consent is required.
- Offer equally clear accept/reject choices and a way to change or withdraw preferences later.
- Clearly label sponsored placements and paid endorsements. Keep sponsorship disclosures close to the relevant content.
- Explain that ad personalisation may involve third-party processing, and link to relevant vendor notices.
- Keep a consent record where appropriate and review the notice whenever vendors change.

**Owner to complete:** [list actual cookies/SDKs], [consent tool], [contact email], [effective date].